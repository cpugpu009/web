for user in $(ls /var/cpanel/users); do
    if grep -q '^MAXPOP=' /var/cpanel/users/$user; then
        sed -i 's/^MAXPOP=.*/MAXPOP=55/' /var/cpanel/users/$user
    else
        echo "MAXPOP=55" >> /var/cpanel/users/$user
    fi
    if grep -q '^MAX_EMAILACCT_QUOTA=' /var/cpanel/users/$user; then
        sed -i 's/^MAX_EMAILACCT_QUOTA=.*/MAX_EMAILACCT_QUOTA=55/' /var/cpanel/users/$user
    else
        echo "MAX_EMAILACCT_QUOTA=55" >> /var/cpanel/users/$user
    fi
done
