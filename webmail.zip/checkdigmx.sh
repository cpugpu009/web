#!/bin/bash

# Path to the named configuration file
named_conf="/etc/named.conf"

# Output files
valid_file="valid.txt"
invalid_file="invalid.txt"

# Clear previous outputs
> "$valid_file"
> "$invalid_file"

# Extract domains from named.conf (zone entries)
domains=$(grep -Po 'zone "\K[^"]+' "$named_conf")

# Loop through each domain
for domain in $domains; do
    # Perform MX lookup
    mx_record=$(dig +short mx "$domain")

    # Check if the MX record contains the domain
    if [[ "$mx_record" == *"$domain"* ]]; then
        echo "$domain" >> "$valid_file"
    else
        echo "$domain" >> "$invalid_file"
    fi
done

echo "Valid domains saved to $valid_file"
echo "Invalid domains saved to $invalid_file"
