#!/bin/bash

# Set the desired quota in blocks (1 block = 1 KB, so 2048000 blocks = 2 GB)
SOFT_LIMIT=2048000
HARD_LIMIT=2048000

# Loop through each user in the /home directory
for user in $(ls /home); do
  # Check if the user has a valid quota (skip system users or directories without quotas)
  if id "$user" &>/dev/null; then
    echo "Setting quota for user: $user"

    # Open the user's quota file for editing
    edquota -u "$user" <<EOF
      $(findmnt -n --output SOURCE --target /home)                    $SOFT_LIMIT      $SOFT_LIMIT    $HARD_LIMIT     0        0        0
EOF

    echo "Quota set for $user: Soft Limit = $SOFT_LIMIT, Hard Limit = $HARD_LIMIT"
  else
    echo "Skipping $user: Not a valid user."
  fi
done

# Recheck quotas to apply changes
quotacheck -avugm
quotaon -avug

echo "Quota update completed for all users."
